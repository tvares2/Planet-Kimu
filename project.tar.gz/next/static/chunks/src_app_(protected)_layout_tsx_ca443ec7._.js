(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9cf8d870._.js",
  "static/chunks/src_ddeb4cb0._.js"
],
    source: "dynamic"
});
