(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_c8d69288._.js",
  "static/chunks/node_modules_recharts_es6_3117cb10._.js",
  "static/chunks/node_modules_1f76e07d._.js",
  "static/chunks/src_a2dabf5a._.js"
],
    source: "dynamic"
});
