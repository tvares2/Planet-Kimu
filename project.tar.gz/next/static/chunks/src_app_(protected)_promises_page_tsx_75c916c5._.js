(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f2ed3d8e._.js",
  "static/chunks/src_components_ui_tooltip_tsx_4a75f541._.js"
],
    source: "dynamic"
});
