(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_4ce0ac6a._.js",
  "static/chunks/src_app_(protected)_gifts_gifts_8dc2019e.css"
],
    source: "dynamic"
});
