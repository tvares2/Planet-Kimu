export const firebaseConfig = {
  "projectId": "studio-8795695143-d83d9",
  "appId": "1:840605063460:web:ec728202a60553ac503bb1",
  "apiKey": "AIzaSyBc0wyko8ywTTjGmxQYThwRewVeSxtPzWQ",
  "authDomain": "studio-8795695143-d83d9.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "840605063460"
};
