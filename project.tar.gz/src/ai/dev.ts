import { config } from 'dotenv';
config();

import '@/ai/flows/generate-reasons-for-love.ts';