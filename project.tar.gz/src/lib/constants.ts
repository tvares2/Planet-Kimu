export const HER_NAME = 'Mimu';
export const PASSWORD = 'forever';
export const PASSWORD_HINT = 'Our favorite promise.';

// Dates for the counter
export const FIRST_MET_DATE = new Date('2022-10-05');
export const FRIENDSHIP_DATE = new Date('2022-10-20');
export const LOVE_DATE = new Date('2023-12-20');

export const SECRET_KEYWORD = 'mimu';
